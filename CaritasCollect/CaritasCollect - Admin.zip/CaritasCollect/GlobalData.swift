//
//  GlobalData.swift
//  CaritasCollect
//
//  Created by Alumno on 26/09/23.
//

import SwiftUI

class GlobalData: ObservableObject {
    var administradorID: Int = 0
}
