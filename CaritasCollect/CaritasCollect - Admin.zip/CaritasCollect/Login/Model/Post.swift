//
//  Post.swift
//  CaritasCollect
//
//  Created by Alumno on 13/10/23.
//

import Foundation

struct Post: Codable {
    var id: Int
    var title: String
}
