//
//  Get.swift
//  CaritasCollect
//
//  Created by Santiago Remes Inguanzo on 16/10/2023.
//

import Foundation

struct Get : Codable {
    var id: Int
    var mensaje: String
    var success: Bool
}
