//
//  CaritasCollectApp.swift
//  CaritasCollect
//
//  Created by Alumno on 13/10/23.
//

import SwiftUI

@main
struct CaritasCollectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
