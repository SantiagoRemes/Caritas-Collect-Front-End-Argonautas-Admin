//
//  RecolectorId.swift
//  CaritasCollect
//
//  Created by Alumno on 13/10/23.
//

import Foundation

var idAdministrador = 1
